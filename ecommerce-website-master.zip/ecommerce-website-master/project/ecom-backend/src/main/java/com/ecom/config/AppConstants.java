package com.ecom.config;

public class AppConstants {
	
	public static final String PAGE_NUMBER_STRING="0";
	public static final String PAGE_SIZE_STRING="25";
	public static final String SORT_BY_STRING="productId";
	public static final String SORT_DIR_STRING="asc";
	
	

}
