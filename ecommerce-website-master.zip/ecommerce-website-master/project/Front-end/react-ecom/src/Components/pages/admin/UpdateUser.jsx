import React from "react";

function UpdateUser(){
    
    return(
        <h1>Hello</h1>
    )
}
export default UpdateUser